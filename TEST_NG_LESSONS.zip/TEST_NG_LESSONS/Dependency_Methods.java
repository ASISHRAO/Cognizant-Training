package TEST_NG_LESSONS;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Dependency_Methods 
{
	//@BeforeClass
	@Test
	void login() 
	  {
		System.out.println("This is login");
	  }
	  @Test(priority=1,dependsOnMethods= {"login"})
	  void search()
	  {
		  System.out.println("This is search");
		  Assert.assertTrue(false);
	  }
	  @Test(priority=2,dependsOnMethods= {"login","search"})
	  void advsearch()
	  {
		  System.out.println("This is advsearch");
	  }
	  
	  @Test(priority=2,dependsOnMethods= {"login"})
	  void logout()
	  {
		  System.out.println("This is logout");
	  }
}
