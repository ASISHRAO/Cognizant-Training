package TEST_NG_LESSONS;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
/*
 * open app
 * test logo
 * login
 * close
 */
import org.testng.annotations.Test;

public class OrangeHRMTest 
{
	public WebDriver driver;
  @Test(priority=1)
  void openapp() 
  {
	    driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		System.out.println("Logo diplayed status1");
		
	
  }
  @Test(priority=2)
  void testlogo()
  {
	 // WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	  //WebElement wi = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@alt='company-branding']")));
	  boolean Ststus= driver.findElement(By.xpath("//img[@alt='company-branding']")).isDisplayed();
	  System.out.println("Logo diplayed status :"+Ststus);
  }
  @Test(priority=3)
  void login()
  {
	  	driver.findElement(By.xpath("/html/body/div/div[1]/div/div[1]/div/div[2]/div[2]/form/div[1]/div/div[2]/input")).sendKeys("Admin");
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[2]/div/div[2]/input")).sendKeys("admin123");
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
		System.out.println("Logo diplayed status3");
  }
  @Test(priority=4)
  void close()
  {
	  System.out.println("Logo diplayed status4");
	  driver.close();
  }
}
