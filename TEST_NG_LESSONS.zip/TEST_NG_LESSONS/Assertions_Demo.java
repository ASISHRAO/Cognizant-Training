package TEST_NG_LESSONS;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assertions_Demo 
{
  @Test
  public void f()
  {
	  //Hard Assertions
	  /*
	  Assert.assertEquals("xyz", "xyz");
	  Assert.assertEquals("xyz", "xyzq");
	  
	  Assert.assertNotEquals("xyz", "xyz");
	  Assert.assertNotEquals("xyz", "x1z");
	  
	  Assert.assertTrue(true);
	  Assert.assertTrue(false);
	  
	  Assert.assertTrue(1==2);
	  Assert.assertTrue(1==1);
	  
	  Assert.assertFalse(true);
	  Assert.assertFalse(1==2);
	  */
//------------------------------------------------------------------------------------------------------------	  
	  //Soft Assertions
	  
	  //why we should not use hard asserts
	  //example
	  
//	  System.out.println("Hi");
//	  System.out.println("Hi");
//	  
//	  Assert.assertEquals("xyz", "xyz");
//	  
//	  System.out.println("hi");
//	  System.out.println("hi");
	  
//------->	  //if it failed the next statement will not execute
//	  System.out.println("hi");
//	  System.out.println("hi");
//	  
//	  Assert.assertEquals("xyz", "xy1");
//	  
//	  System.out.println("Hi");
//	  System.out.println("Hi");
//--------------------------------------------------------------------------------------------------------------------------------	
	  //----->Soft Assertion
	  System.out.println("hi");
	  System.out.println("hi");
	  
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals("xyz", "xy1");//if no assertAll it will pass
	  
	  System.out.println("Hi");
	  System.out.println("Hi");
	  
	  sa.assertAll();//mandatory
  }
}
