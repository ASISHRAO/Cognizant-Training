package TEST_NG_LESSONS;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Annotation_class 
{
	@BeforeMethod
	void login() 
	  {
		System.out.println("This is login");
	  }
	  @Test(priority=2)
	  void search()
	  {
		  System.out.println("This is search");
	  }
	  @Test(priority=3)
	  void advsearch()
	  {
		  System.out.println("This is advsearch");
	  }
	  
	  @AfterMethod
	  void logout()
	  {
		  System.out.println("This is logout");
	  }
}
