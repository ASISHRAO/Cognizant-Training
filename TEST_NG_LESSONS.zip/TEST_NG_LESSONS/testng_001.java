package TEST_NG_LESSONS;

import org.testng.annotations.Test;

/*
 * open app
 * login
 * logout
 */
public class testng_001 
{
	@Test(priority=1)
	void openapp()
	{
		System.out.println("app opended");
	}
	@Test(priority=2)
	void login()
	{
		System.out.println("app Logined");
	}
	@Test(priority=3)
	void loginout()
	{
		System.out.println("app LogOut");
	}
}
