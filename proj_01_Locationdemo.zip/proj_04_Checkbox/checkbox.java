package proj_04_Checkbox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class checkbox {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();//setup the web driver manager
		
		ChromeDriver driver = new ChromeDriver();//object call for browser
		
		driver.get("https://www.lambdatest.com/selenium-playground/checkbox-demo");//get or display the browser
		
		//WebElement country = driver.findElement(By.name("country"));
		
		boolean b = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/section/div/div/div[1]/label/input")).isEnabled();	
		System.out.println(b);
		
		
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div/section/div/div/div[2]/div/label[1]")).click();
	}

}
