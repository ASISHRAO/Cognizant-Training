package prog_explict_demo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

//import Mouse.webElement;
import io.github.bonigarcia.wdm.WebDriverManager;

public class explicit_demo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
WebDriverManager.chromedriver().setup();//setup the web driver manager
		
		ChromeDriver driver = new ChromeDriver();//object call for browser
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		
		driver.get("https://www.lambdatest.com/selenium-playground/bootstrap-progress-bar-dialog-demo");//get or display the browser
		
		
		
	}
}
