package Page_Object_Model_Demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login_page 
{
	//Constroctor
	WebDriver driver;
	Login_page(WebDriver driver)
	{
		this.driver = driver;
	}
	//Locators
	
	By username = By.xpath("/html/body/div/div[1]/div/div[1]/div/div[2]/div[2]/form/div[1]/div/div[2]/input");
	By password = By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[2]/div/div[2]/input");
	By login = By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button");
	
	//Actions Methods
	
	public void setUsername(String user)
	{
		driver.findElement(username).sendKeys(user);
	}
	
	public void setPassword(String pwd)
	{
		driver.findElement(password).sendKeys(pwd);
	}
	
	public void clickOnLogin()
	{
		driver.findElement(login).click();
	}
}
