package proj_01_Basic;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OpenWebSite 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();//setup the web driver manager
		
		ChromeDriver driver = new ChromeDriver();//object call for browser
		
		driver.get("https://www.selenium.dev/");//get or display the browser
		//driver.manage().window().maximize();//full screen for the browser
		
		String actualPageTitle = driver.getTitle();//to get the title of the project or website.
		System.out.println(actualPageTitle);
		
		String headingText = driver.findElement(By.tagName("h2")).getText();//findelement is used for finding the tag in page and get it
		System.out.println(headingText);
		
		
		String formHeading = driver.findElement(By.tagName("h1")).getText();	
		System.out.println(formHeading);
		
		//driver.getClass() - class elements
		
		
		
	}

}
