package proj_01_Locationdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Location 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		
		EdgeDriver driver = new EdgeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://accounts.lambdatest.com/login?_gl=1*azrjqo*_gcl_au*MTAzNTkxODIyNC4xNzQ4NTE3NjI2");
		
		driver.findElement(By.id("email")).sendKeys("asi@gmail.com");
		
		driver.findElement(By.name("password")).sendKeys("asish123");
		
		//driver.findElement(By.linkText("Login")).click();
		
		driver.findElement(By.partialLinkText("Log")).click();
		
		
		
		}

}
