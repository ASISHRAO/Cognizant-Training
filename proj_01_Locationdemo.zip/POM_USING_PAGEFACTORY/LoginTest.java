package POM_USING_PAGEFACTORY;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LoginTest 
{
	WebDriver driver;
	@BeforeClass
	void setup()
	{
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
	}
	
	@Test
	void login()
	{
		Login_page lp = new Login_page(driver);
		lp.setUsername("admin");
		lp.setPassword("admin123");
		lp.clickOnLogin();
	}
	
	@AfterClass
	void close()
	{
		driver.close();
	}

}
