package access_multiple_tab;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class multiple_tab {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();//setup the web driver manager
		
		ChromeDriver driver = new ChromeDriver();//object call for browser
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");//get or display the browser
		
		String org_wind = driver.getWindowHandle();//handle existing window
		System.out.println(org_wind);
		
		
		driver.findElement(By.partialLinkText("OrangeHRM")).click();
		
		Set<String> all_wind = driver.getWindowHandles();//handle existing all tabs and window with in set
		System.out.println(all_wind);
		
		for(String han : all_wind)
		{
			if(!han.equals(org_wind))
			{
				driver.switchTo().window(han);
				System.out.println(driver.getTitle());
				driver.close();//to close the existing tab
				//driver.quit(); to close all tab
			}
		}
		
		driver.switchTo().window(org_wind);
		System.out.println(driver.getTitle());
		
		
		
	}
}
