package proj_03_select;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class select {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();//setup the web driver manager
		
		ChromeDriver driver = new ChromeDriver();//object call for browser
		
		driver.get("https://www.lambdatest.com/selenium-playground/input-form-demo");//get or display the browser
		
		WebElement country = driver.findElement(By.name("country"));
		
		Select countryDropdown = new Select(country);
		
		countryDropdown.selectByVisibleText("India");//select value by text
		
		countryDropdown.selectByIndex(8);//value by index
		
		//countryDropdown.selectByValue("D2");//select by value
		
		List<WebElement> countryList = countryDropdown.getOptions();
		
		for(WebElement co : countryList)
		{
			String cont_name = co.getText();
			System.out.println(cont_name);
		}
		
		
	}

}
