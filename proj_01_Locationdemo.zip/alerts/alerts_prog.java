package alerts;

import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class alerts_prog {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();//setup the web driver manager
		
		ChromeDriver driver = new ChromeDriver();//object call for browser
		
		driver.get("https://www.makemytrip.com/");//get or display the browser
		
		
	}

}
