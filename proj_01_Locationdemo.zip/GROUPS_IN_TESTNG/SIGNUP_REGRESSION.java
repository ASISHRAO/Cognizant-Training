package GROUPS_IN_TESTNG;

import org.testng.annotations.Test;

public class SIGNUP_REGRESSION 
{
	 @Test(priority = 1,groups = {"regression"})
	  public void signupemail() 
	  {
		  System.out.println("signup with email");
	  }
	  
	  @Test(priority = 2,groups = {"regression"})
	  public void signupfacebook() 
	  {
		  System.out.println("signup with facebook");
	  }
	  
	  @Test(priority = 3,groups = {"regression"})
	  public void signuptwitter() 
	  {
		  System.out.println("signup with twitter");
	  }
}
