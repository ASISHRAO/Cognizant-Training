package GROUPS_IN_TESTNG;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class LOGIN_SANITY 
{
  @Test(priority = 1,groups = {"sanity"})
  public void loginemail() 
  {
	  System.out.println("Login with email");
  }
  
  @Test(priority = 2,groups = {"sanity"})
  public void loginfacebook() 
  {
	  System.out.println("Login with facebook");
  }
  
  @Test(priority = 3,groups = {"sanity"})
  public void logintwitter() 
  {
	  System.out.println("Login with twitter");
  }
}
