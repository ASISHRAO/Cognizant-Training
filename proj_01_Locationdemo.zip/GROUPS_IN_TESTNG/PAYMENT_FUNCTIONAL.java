package GROUPS_IN_TESTNG;

import org.testng.annotations.Test;

public class PAYMENT_FUNCTIONAL {
  @Test(priority = 1,groups = {"sanity","regression","functional"})
  public void payinrupee() {
	  System.out.println("Pay in rupees");
  }
  @Test(priority = 2,groups = {"sanity","regression","functional"})
  public void payindoller() {
	  System.out.println("Pay in doller");
  }
}
