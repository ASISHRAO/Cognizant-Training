package Mini_Project_HRM_Asish;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HRM 
{

	public static void main(String[] args) throws InterruptedException 
	{
		// TODO Auto-generated method stub
		//-->Launch the browser Chrome/Firefox
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
		//String mainpage = driver.getWindowHandle();
//		-->Enter the given Username and Password
//		Click the “Login” button.
		driver.findElement(By.xpath("/html/body/div/div[1]/div/div[1]/div/div[2]/div[2]/form/div[1]/div/div[2]/input")).sendKeys("Admin");
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[2]/div/div[2]/input")).sendKeys("admin123");
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
		
		
		//Verify the current URL and check if it contains the string “dashboard”.
		WebElement dashboard = driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[8]/a"));
		boolean Status = dashboard.isDisplayed();
		System.out.println(Status);
		
		//-->Go to Admin Tab
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a")).click();
		
		//-->Go to the Job tab and check ‘Job Titles’ is there or not.
		

	
		
		
		//--->Click on “Job Titles”
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[2]/nav/ul/li[2]/span")).click();
		
	
		
		
//		
//		
		

		
		
		
		
		
		
		//--->Click on “Add Button” icon, add job as “Automation Tester”.
		//*[@id="app"]/div[1]/div[1]/header/div[2]/nav/ul/li[2]/ul/li[1]
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[2]/nav/ul/li[2]/ul/li[1]")).click();
		
		//list jobs
		List<WebElement> jobs = driver.findElements(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/div[3]/div/div[2]/div/div/div[2]/div"));
		int size = jobs.size();
		System.out.println("size - "+size);
		
		for(int i =0;i<jobs.size();i++)
		{
			System.out.println(jobs.get(i).getText());
			
		}
		
		
		
		//add button click
		//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div[1]/div/button
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/div[1]/div/button")).click();
		
		//Add job description
		
		//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/input
		Thread.sleep(5000);
		
		//--->job title enter
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/input")).sendKeys("AutoMation005");
		
		//--->job description enter
		//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[2]/textarea
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[2]/textarea")).sendKeys("want selenium with java automation tester ");
		
		//send detail in file
		//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[3]/div/div[2]/div/i
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[3]/div/div[2]/input")).sendKeys("C:\\Users\\2408349\\Downloads\\Session1.pdf");
		
		//Note
		//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[4]/div/div[2]/textarea
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[4]/div/div[2]/textarea")).sendKeys("Apply properly");
		
		//Save click
		//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[5]/button[2]
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[5]/button[2]")).click();
		
		
		//Logout and close browser
		
		//*[@id="app"]/div[1]/div[1]/header/div[1]/div[3]/ul/li/span/img
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[3]/ul/li/span/img")).click();
		
		//*[@id="app"]/div[1]/div[1]/header/div[1]/div[3]/ul/li/ul/li[4]/a
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[3]/ul/li/ul/li[4]/a")).click();
		
		driver.close();
		//
		
		
	
	}

}
