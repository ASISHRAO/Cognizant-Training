package Demo_for_screenshort;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.v135.page.model.Screenshot;

import io.github.bonigarcia.wdm.WebDriverManager;

public class screen_short {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();//setup the web driver manager
		
		ChromeDriver driver = new ChromeDriver();//object call for browser
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		
		driver.get("https://www.lambdatest.com/selenium-playground/bootstrap-progress-bar-dialog-demo");//get or display the browser
		
		//TakesScreenshot screenshot = null; 
		
		TakesScreenshot screenshot = (TakesScreenshot)driver;
		
		
		File sourcefile = screenshot.getScreenshotAs(OutputType.FILE);
		
		File target  = new File("C:\\Users\\2408349\\eclipse-workspace\\selenium_proj\\screenshot");
		
		FileUtils.copyFile(sourcefile, target);
		
	
	}
}
