package DataProvider_TestNG_Demo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Data_Provider 
{
	WebDriver driver;
  @BeforeClass
  @Parameters({"browser","url"})
  void driver_setup(String br,String url) throws InterruptedException
  {
	  switch(br){
	  case "chrome":driver = new ChromeDriver();break;
	  case "firefox":driver = new FirefoxDriver();break;
	  case "edge":driver = new EdgeDriver();break;
	  default :return;
	  
	  }
	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	 driver.get(url);
	  driver.manage().window().maximize();
	  Thread.sleep(3000);
  }
  
  
  @SuppressWarnings("unused")
@Test(dataProvider="dp")
  void login(String n, String s) throws InterruptedException
  {
	  driver.findElement(By.xpath("/html/body/div/div[1]/div/div[1]/div/div[2]/div[2]/form/div[1]/div/div[2]/input")).sendKeys(n);
	  driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[2]/div/div[2]/input")).sendKeys(s);
	  driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
	
	
	//Verify the current URL and check if it contains the string “dashboard”.
	WebElement dashboard = driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[8]/a"));
	boolean Status = dashboard.isDisplayed();
	if(Status = true)
	{
		System.out.println("Passed......");
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[3]/ul/li/span/img")).click();
		
		//*[@id="app"]/div[1]/div[1]/header/div[1]/div[3]/ul/li/ul/li[4]/a
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[3]/ul/li/ul/li[4]/a")).click();
		
		Assert.assertTrue(true);
	}
	else
	{
		System.out.println("failed......");
		Assert.fail();
	}
	
  
  }


  @AfterClass
  public void afterClass() 
  {
	  driver.close();
  }
  
  @DataProvider (name = "dp",indices= {0,3})
  public Object[][] loginData() 
  {
	  Object data[][]= {   
				{"admin", "admin123"},
				{"xyz@gmail.com", "test012"},
				{"john@gmail.com", "test@123"},
				{"pavanol123@gmail.com", "test@123"},
				{"johncanedy@gmail.com", "test"},
	
			};
	  
      return data;
  }

}
