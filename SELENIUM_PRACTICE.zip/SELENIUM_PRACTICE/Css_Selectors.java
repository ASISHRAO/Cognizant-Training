package SELENIUM_PRACTICE;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Css_Selectors 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.nopcommerce.com/");
		
		driver.manage().window().maximize();
		//tag#id
		driver.findElement(By.cssSelector("#small-searchterms")).sendKeys("tshirt");
		
		//tag class
		driver.findElement(By.cssSelector(".search-box-button")).click();
		
		
		//tag attribute
		driver.findElement(By.cssSelector("input[placeholder='Search store']")).sendKeys("hello");
		
		
		//tag claa attribute
		driver.findElement(By.cssSelector("input.search-box-text[name='q']")).sendKeys("hello");
		
		
	}

}
