package SELENIUM_PRACTICE;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class CaptureScreenShot 
{
	public static void main(String args[])
	{
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--headless=new");
		WebDriver driver = new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://demo.nopcommerce.com/");
		driver.manage().window().maximize();
		/*
		//1)Take Full screen Shot)
		TakesScreenshot ts = (TakesScreenshot)driver;
		File sourcefile = ts.getScreenshotAs(OutputType.FILE);
		//File targetfile =new File("C:\\Users\\2408349\\eclipse-workspace\\selenium_proj\\screenshot");
		//or
		File targetfile =new File(System.getProperty("user.dir")+"\\screenshot\\fullpage.png");
		sourcefile.renameTo(targetfile);
		*/
		//2)specific part screenshot
		WebElement feature = driver.findElement(By.xpath("//div[@class='product-grid home-page-product-grid']"));
		File sourcefile = feature.getScreenshotAs(OutputType.FILE);
		File targetfile =new File(System.getProperty("user.dir")+"\\screenshot\\specificHeadless.png");
		sourcefile.renameTo(targetfile);
		driver.close();
		
		
	}
}
