package SELENIUM_PRACTICE;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Handle_Alerts 
{

	public static void main(String[] args) throws InterruptedException 
	{
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();
		/*
		
		//1)Normal alert with OK button
	driver.findElement(By.xpath("//button[normalize-space()='Click for JS Alert']")).click();
	Alert myalert = driver.switchTo().alert();
		Thread.sleep(5000);
	myalert.accept();
		
		//2)conformation Alert - Ok&Cancel;
		driver.findElement(By.xpath("//button[normalize-space()='Click for JS Confirm']")).click();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		driver.switchTo().alert().dismiss();
*/		
		//3)Prompt alert 
		driver.findElement(By.xpath("//button[normalize-space()='Click for JS Prompt']")).click();
		Thread.sleep(5000);
		Alert myalert = driver.switchTo().alert();
		System.out.println("Text msg "+myalert.getText());
		myalert.sendKeys("welcome");
		myalert.accept();
	}

}
