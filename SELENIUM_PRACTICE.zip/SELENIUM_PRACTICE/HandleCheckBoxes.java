package SELENIUM_PRACTICE;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleCheckBoxes 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		/*
		//1) select check box
		WebElement checkbox = driver.findElement(By.xpath("//input[@id='sunday']"));
		System.out.println("Before Selection:"+checkbox.isSelected());
		driver.findElement(By.xpath("//input[@id='sunday']")).click();
		System.out.println("After Selection:"+checkbox.isSelected());
		*/
		//2) capturing all the checkboxes
		List<WebElement> check = driver.findElements(By.xpath("//input[@class='form-check-input' and @type='checkbox']"));
		System.out.println("No of ckeck" + check.size());
		
		
		//3)select all the checkboxes
		for(int i =0;i<=check.size();i++)
		{
			check.get(i).click();
		}
		
		//4) Select/unselect checkbox
		for(WebElement ch : check)
		{
			if(ch.isSelected())
			{
				ch.click();//unselect
			}
			else
			{
				ch.click();//select
			}
		}
	}

}
