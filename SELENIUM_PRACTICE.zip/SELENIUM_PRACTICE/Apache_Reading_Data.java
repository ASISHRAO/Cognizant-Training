package SELENIUM_PRACTICE;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Apache_Reading_Data 
{
//Excel File --->Workbook --->Sheets --->Rows ---Cells
	public static void main(String[] args) throws IOException 
	{
		// TODO Auto-generated method stub
		//Excel File
		FileInputStream file = new FileInputStream(System.getProperty("user.dir")+"\\testData\\Book1.xlsx");
		
		//Workbook
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		
		//Sheet
		XSSFSheet sheet = workbook.getSheet("Sheet1");
		
		//Rows
		int Tot_Rows = sheet.getLastRowNum();
		int Tot_Cells = sheet.getRow(1).getLastCellNum();
		
		System.out.println("No.of rows:"+Tot_Rows);//rows count from 0
		System.out.println("No.of cells:"+Tot_Cells);//cells count from 1
		
		//Reading Data from excel sheet.
		for(int r =0;r<=Tot_Rows;r++)
		{
			XSSFRow curr_row = sheet.getRow(r);
			for(int c=0;c<Tot_Cells;c++)
			{
				XSSFCell curr_cell = curr_row.getCell(c);
				System.out.print(curr_cell.toString()+"\t");
			}
			System.out.println();
			
		}
		workbook.close();
		file.close();
		
	}

}
