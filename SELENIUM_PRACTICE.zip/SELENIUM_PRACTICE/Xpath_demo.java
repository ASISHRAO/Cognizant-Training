package SELENIUM_PRACTICE;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Xpath_demo {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.nopcommerce.com/");
		//absolute xpath(partial xpath)
		driver.findElement(By.xpath("//*[@id=\"small-searchterms\"]")).sendKeys("Hello");
		
		//relavtive xpath(full xpath)
		driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[2]/div[2]/form/input")).sendKeys("Hello");
		
		///listion xpath and xpath axis .
		
		
		
		
	}

}
