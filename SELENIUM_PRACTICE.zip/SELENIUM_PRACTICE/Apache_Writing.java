package SELENIUM_PRACTICE;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Apache_Writing 
{
	//getting Dyanamic data
	public static void main(String[] args) throws IOException 
	{
		// TODO Auto-generated method stub
		FileOutputStream file = new FileOutputStream(System.getProperty("user.dir")+"\\testData\\mydynmicfile.xlsx");
		
		//Workbook
		XSSFWorkbook workbook = new XSSFWorkbook();
				
		//Sheet
		XSSFSheet sheet = workbook.createSheet("DynamicData");
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the num of rows");
		int Tot_Rows = sc.nextInt();
		System.out.println("Enter the num of cells");
		int Tot_Cells = sc.nextInt();
		
		//Reading Data from excel sheet.
		for(int r =0;r<=Tot_Rows;r++)
		{
			XSSFRow curr_row = sheet.createRow(r);
			
			for(int c=0;c<Tot_Cells;c++)
			{
				XSSFCell curr_cell = curr_row.createCell(c);
				curr_cell.setCellValue(sc.next());
			}
			System.out.println();
			
		}
		
		workbook.write(file);
		workbook.close();
		file.close();
		System.out.println("File is Created....");
	}
}
