package SELENIUM_PRACTICE;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Methods___Conditional_Methods 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		WebDriver driver  = new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/register");
		driver.manage().window().maximize();
		
		//------>isDisplayed()
		WebElement logo1 = driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']"));
		System.out.println("Display ststus of logo :"+logo1.isDisplayed());
		
		//or
		boolean logo = driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']")).isDisplayed();
		System.out.println("Display ststus of logo :"+logo);
		
		//------>isEnabled()
		boolean status = driver.findElement(By.xpath("//input[@id='FirstName']")).isEnabled();
		System.out.println("Display ststus of firstname :"+status);
		
		//------>isSelected()
		//male is not selected
		boolean statu = driver.findElement(By.xpath("//input[@id='gender-male']")).isSelected();
		System.out.println("Display ststus of gender :"+statu);
		
		//after selecting male radio dutton
		WebElement select_male = driver.findElement(By.xpath("//input[@id='gender-male']"));
		select_male.click();
		boolean statu1 = driver.findElement(By.xpath("//input[@id='gender-male']")).isSelected();
		System.out.println("Display ststus of gender after selcting male radio button :"+statu1);
		
		

	}

}
