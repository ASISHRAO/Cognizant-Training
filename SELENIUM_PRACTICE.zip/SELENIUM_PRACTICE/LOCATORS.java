package SELENIUM_PRACTICE;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LOCATORS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//NAME LOCATOR
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.opencart.com/");
		//name
		driver.findElement(By.name("search")).sendKeys("hi bro");
		//id
		boolean status = driver.findElement(By.id("logo")).isDisplayed();
		
		System.out.println("Disply"+status);
		//link text
		driver.findElement(By.linkText("search")).click();
		//partial link text
		driver.findElement(By.partialLinkText("search")).click();
		
		//class name
		List<WebElement> headLinks = driver.findElements(By.className("list-inline-item"));
		System.out.println(headLinks.size());//group of webelements
		
		//tagname
		
		List<WebElement> links =  driver.findElements(By.tagName("a"));
		System.out.println(links.size());
		
		List<WebElement> image =  driver.findElements(By.tagName("img"));
		System.out.println(image.size());
		
		
		
		
	}

}
