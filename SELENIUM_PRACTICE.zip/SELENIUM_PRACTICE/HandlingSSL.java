package SELENIUM_PRACTICE;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HandlingSSL 
{
	public static void main(String args[])
	{
		//test headerless
		/*
		 * ChromeOptions options = new ChromeOptions();
		options.addArguments("--headless=new");
		WebDriver driver = new ChromeDriver(options);
		
		 */
		//SSL
	ChromeOptions options = new ChromeOptions();
	options.setAcceptInsecureCerts(true);
	WebDriver driver = new ChromeDriver(options);
	driver.get("https://expired.badssl.com/");
	System.out.println(driver.getTitle()+"Tile");
	}
	
}
