package SELENIUM_PRACTICE;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Methods____Get_Method 
{

	public static void main(String[] args) throws InterruptedException 
	{
		// TODO Auto-generated method stub
		//------>get(url)
		WebDriver driver  = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		Thread.sleep(5000);
		
		//------>getTitle()
		String str = driver.getTitle();
		System.out.println(str);
		
		//------>getCurrentUrl()
		String url = driver.getCurrentUrl();
		System.out.println(url);
		
		//------>getPageSource
		String ps = driver.getPageSource();
		System.out.println(ps);
		
		//------>getWindowHandle()
		String wh = driver.getWindowHandle();
		System.out.println("Window ID :"+wh);
		
		
		//------>getWindowHandles
		driver.findElement(By.linkText("OrangeHRM, Inc")).click();
		Set<String> windowids = driver.getWindowHandles();
		System.out.println("Windows ids-"+windowids);
		
		
	}

}
