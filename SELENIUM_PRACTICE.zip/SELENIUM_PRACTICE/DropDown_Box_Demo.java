package SELENIUM_PRACTICE;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDown_Box_Demo 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//driver.get("https://testautomationpractice.blogspot.com/");
		//driver.manage().window().maximize();
		/*
		WebElement wd = driver.findElement(By.xpath("//select[@id='country']")); 
		Select sel = new Select(wd);
//-------------------------------------------------------------------------------------		
		//Select DropDown Methods
		/*
		sel.selectByVisibleText("France");
		sel.selectByValue("canada");
		sel.selectByIndex(3);
		
		//capture options from the dropdown
		List<WebElement> lwd = sel.getOptions();
		System.out.println("Size of the drop down :"+lwd.size());
		
		//print all the options
		for(WebElement x : lwd)
		{
			System.out.println(x.getText());
		}
		
//------------------------------------------------------------------------------------------------------------------------------------		
		
		//BootStrap DropDown 
		driver.get("https://www.jquery-az.com/boots/demo.php?ex=63.0_2");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//button[contains(@class,'multiselect')]")).click();
		//1)Select single option
		
		driver.findElement(By.xpath("//input[@value='Java']")).click();
		
		//2) capture all the options and find out size
		List<WebElement>options = driver.findElements(By.xpath("//ul[contains(@class,'multiselect')]//label"));
		System.out.println("Size of the drop down :"+options.size());
		
		//3)print all the options
		for(WebElement x : options)
		{
			System.out.println(x.getText());
		}
		
		//4)Select multiple options
		for(WebElement x : options)
		{
			String opt = x.getText();
			if(opt.equals("C#") || opt.equals("Python"))
			{
				x.click();
			}
		}
		*/
//-------------------------------------------------------------------------------------------------------------------------------------		
		//Hidden drop down
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
//		-->Enter the given Username and Password
//		Click the “Login” button.
		driver.findElement(By.xpath("/html/body/div/div[1]/div/div[1]/div/div[2]/div[2]/form/div[1]/div/div[2]/input")).sendKeys("Admin");
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[2]/div/div[2]/input")).sendKeys("admin123");
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
		
		//clcick on PIM
		driver.findElement(By.xpath("//spam[normalize-space()='PIM']")).click();
		
		
		
		
		
		

	}

}
