package SELENIUM_PRACTICE;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Apache_Writing_Data 
{
	//Excel File --->Workbook --->Sheets --->Rows ---Cells

	public static void main(String[] args) throws IOException 
	{
		// TODO Auto-generated method stub
		FileOutputStream file = new FileOutputStream(System.getProperty("user.dir")+"\\testData\\myfile.xlsx");
		
		//Workbook
		XSSFWorkbook workbook = new XSSFWorkbook();
				
		//Sheet
		XSSFSheet sheet = workbook.createSheet("Data");
				
		//Insert Rows and Columns
		XSSFRow row1 = sheet.createRow(0);
		row1.createCell(0).setCellValue("Java");
		row1.createCell(1).setCellValue(1);
		row1.createCell(2).setCellValue("Automation");
		
		XSSFRow row2 = sheet.createRow(1);
		row1.createCell(0).setCellValue("Python");
		row1.createCell(1).setCellValue(1);
		row1.createCell(2).setCellValue("Automation");
		
		XSSFRow row3 = sheet.createRow(2);
		row1.createCell(0).setCellValue("C#");
		row1.createCell(1).setCellValue(1);
		row1.createCell(2).setCellValue("Automation");
		
		workbook.write(file);
		workbook.close();
		file.close();
		
		System.out.println("File is created......");
		
		
	}	
		
}	