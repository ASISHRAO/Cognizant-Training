package SELENIUM_PRACTICE;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Handle_Windows_demo 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		WebDriver driver  = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("OrangeHRM, Inc")).click();
		Set<String> windowsIds =  driver.getWindowHandles();
		
		//Approch-1
		//Convet set into arraylist ot list
		
	/*	List<String> winlist = new ArrayList(windowsIds);
		String parId = winlist.get(0);
		String childId = winlist.get(1);
		
		//switch to child window
		driver.switchTo().window(childId);
		System.out.println(driver.getTitle());
		
		//switch to parent window.
		driver.switchTo().window(parId);
		System.out.println(driver.getTitle());*/
		
		
		//Approch-2
		//for multiple windows
		
//		for(String Winid:windowsIds)
//		{
//			String title = driver.switchTo().window(Winid).getTitle();
//			
//			if(title.equals("OrangeHRM"))
//			{
//				System.out.println(driver.getCurrentUrl());
//			
//				//
//			}
//		}
//		
		
		//closing particular window
		for(String Winid:windowsIds)
		{
			String title = driver.switchTo().window(Winid).getTitle();
			System.out.println(title);
			if(title.equals("OrangeHRM"))
			{
				System.out.println(driver.getCurrentUrl());
				driver.close();
				break;
				//
			}
		}
		
		//close 2 or more windows
		for(String Winid:windowsIds)
		{
			String title = driver.switchTo().window(Winid).getTitle();
			System.out.println(title);
			if(title.equals("OrangeHRM")||title.equals("id2--"))
			{
				System.out.println(driver.getCurrentUrl());
				driver.close();
			
				
			}
		}
		
		
	}

}
