package test;

import java.io.IOException;

import org.testng.annotations.Test;

import base.base;
import page.BookTheCab;
import page.FillTheGiftCartWithInvalidData;
import page.SwitchWindowToGiftcard;
import page.MakeMyTripHomePage;
import page.EnterToLocation;
import page.EnterValidDate;
import page.EnterFromLocation;
import page.EnterTheTime;
public class BaseTest extends base
{ 
	
	
  @Test(priority=1)
  public void TestionHomePage() throws InterruptedException, IOException 
  {
	  MakeMyTripHomePage hm = new MakeMyTripHomePage(driver);
	  hm.closePopup();
	  hm.Closecard();
	  hm.clickOncabs();
	  hm.OutStation();
  }
  
  @Test(priority=3)
  public void SelectLoaction() throws InterruptedException 
  {
	  EnterFromLocation Sl = new EnterFromLocation(driver);
	  Sl.fromcity();
	  Sl.fromInput();
	  Thread.sleep(3000);
	  Sl.fromOptions(); 
	  
  }
  @Test(priority=2)
  public void SelectToLoc()
  {
	  EnterToLocation tl = new EnterToLocation(driver);
	  tl.tocity();
	  tl.toInput();
	  tl.toOptions();
	  
  }
  @Test(priority=4)
  public void selDate() throws InterruptedException
  {
	 EnterValidDate sd = new  EnterValidDate(driver);
	 sd.timePick();
	 sd.datepick();
	 sd.time();
	 Thread.sleep(3000);
  }
  
  @Test(priority=5)
  public void dateTest() throws InterruptedException
  {
	  EnterTheTime dp = new EnterTheTime(driver);
	  dp.s1();
	  dp.s2();
	  dp.s3(); 
	  dp.s4();
	  Thread.sleep(2000); 
  }

  @Test(priority = 6)
  public void selectcab() throws InterruptedException, IOException
  {
	  BookTheCab cb = new BookTheCab(driver);
	  cb.closeFloat();
	  cb.car();
	  cb.prices();
  }
  @Test(priority=7)
  public void scroll() throws InterruptedException 
//		  throws InterruptedException
  {
	  
	  SwitchWindowToGiftcard hw = new SwitchWindowToGiftcard(driver);
	  hw.groupTab();
	  hw.intrested();
	  Thread.sleep(2000);
  }
  @Test(priority=8)
  public void filldata() throws InterruptedException
  {
	  FillTheGiftCartWithInvalidData data = new FillTheGiftCartWithInvalidData(driver);
	  data.giftcard();
	  data.name();
	  data.email();
	  data.phone();
	  data.loc();
	  data.prop();
	  data.gif();
	  data.submit();
	  //Thread.sleep(2000);
  }
  
  @Test(priority=9)
  public void screen() throws IOException, InterruptedException
  {
	  SwitchWindowToGiftcard hw1 = new SwitchWindowToGiftcard(driver);
	  hw1.handle();
  }
  

}
