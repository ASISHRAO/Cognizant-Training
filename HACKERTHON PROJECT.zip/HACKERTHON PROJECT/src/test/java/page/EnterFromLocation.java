package page;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EnterFromLocation 
{
	public WebDriver driver;
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	//constructor
	public EnterFromLocation(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		
	}
	//locator
	@FindBy(id="fromCity")
	WebElement fromcity;
	
	@FindBy(xpath="//input[@placeholder='From']")
	WebElement fromInput;
	
	@FindBy(xpath="//span[contains(text(),'Delhi')]")
	WebElement fromOptions;
	
	
	//Actions
	public void fromcity()
	{
		fromcity.click();
	}
	
	public void fromInput()
	{
		wait.until(ExpectedConditions.elementToBeClickable(fromInput)).sendKeys("Delhi");
	}
	
	public void fromOptions()
	{
		wait.until(ExpectedConditions.elementToBeClickable(fromOptions)).click();
	}
	
	
}
