package page;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EnterValidDate 
{
 
	WebDriver driver;
	WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(5));
	//constructor
	public EnterValidDate(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		
	}
  


	@FindBy(xpath="//p[@data-cy='departureDate']")
	WebElement TimePick;
	
	@FindBy(xpath="//div[@class='DayPicker-Day' and text()='13']")
	WebElement datepick;
	
	@FindBy(xpath="//span[@data-cy='pickupTime']")
	WebElement time;
	
	
	
	public void timePick()
	{
		TimePick.click();
	}
	
	public void datepick()
	{
		wait1.until(ExpectedConditions.elementToBeClickable(datepick)).click();
		
	}
	
	public void time()
	{
		wait1.until(ExpectedConditions.elementToBeClickable(time)).click();
	}
	
	
	
	
}
