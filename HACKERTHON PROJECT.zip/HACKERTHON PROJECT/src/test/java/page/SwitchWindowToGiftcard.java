package page;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SwitchWindowToGiftcard 
{
	private WebDriver driver;
	
	WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(5));
	//constructor
	public SwitchWindowToGiftcard(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	
	
	
	@FindBy(xpath="//button[text()='I’m Interested']")
	WebElement Intrested;
	
	

	
	public void groupTab() throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
		String url = driver.getWindowHandle();
		
		Thread.sleep(2000);
		WebElement menu = driver.findElement(By.xpath("(//li)[11]"));
		Actions actions = new Actions(driver);
		actions.moveToElement(menu).perform();

		WebElement clickableElement = wait.until(ExpectedConditions.elementToBeClickable(
		    By.xpath("(//a[contains(text(), '')])[13]")));
		clickableElement.click();

		Thread.sleep(2000);
		driver.findElement(By.xpath("//img[@data-cy='CorporateGifting_476']")).click();
		
		Set<String> all_wind = driver.getWindowHandles();//handle existing all tabs and window with in set
		//System.out.println(all_wind);
		
		for(String han : all_wind)
		{
			if(!han.equals(url))
			{
				driver.switchTo().window(han);
				//System.out.println(driver.getTitle());
				
			}
		}
	}
	
	public void intrested()
	{
		Intrested.click();
		driver.getWindowHandle();
	}
	
	
	public void handle() throws InterruptedException
	{
		String url = driver.getWindowHandle();
		System.out.println("Extract Adult Options from Hotels");
        
        driver.get("https://www.makemytrip.com/hostels/");
        Set<String> allwind = driver.getWindowHandles();//handle existing all tabs and window with in set
		//System.out.println(allwind);
		
		for(String han1 : allwind)
		{
			if(!han1.equals(url))
			{
				driver.switchTo().window(han1);
				//System.out.println(driver.getTitle());
				
			}
		}
		//String url2 = driver.getWindowHandle();
	       //System.out.println(url2);
     Thread.sleep(2000);
     new Actions(driver).moveByOffset(10, 10).click().perform();
     Thread.sleep(1000);
     
     driver.findElement(By.xpath("//span[text()='Hotels']")).click();
     Thread.sleep(1000);
     
     driver.findElement(By.id("guest")).click();
     driver.findElement(By.xpath("//p[text()='Adults']")).click();
     //WebDriverWait wait4 = new WebDriverWait(driver,Duration.ofSeconds(10));
     //wait4.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='gstSlct__list']/li")));
     WebElement s = driver.findElement(By.xpath("//span[@class='gstSlct__text'  and @data-testid='adult_count']"));
     System.out.println("count : "+s.getText());
//     List<WebElement> adultOption = driver.findElements(By.xpath("//ul[@class='gstSlct__list']/li"));
//     for(WebElement option:adultOption) {
//     	String text = option.getText().trim();
//     	if(!text.isEmpty()) {
//     		System.out.println("value : "+text);
//     	}
//     }
	       
	}
	
}
