package page;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BookTheCab 
{
	WebDriver driver;
	WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(5));
	//constructor
	public BookTheCab(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="/html/body/div[4]/img")
	WebElement closeFloat;
	
	@FindBy(xpath="//span[text()='SUV']")
	WebElement selectCar;
	
	@FindBy(xpath="//span[@class='cabDetailsCard_price__SHN6W']")
	List<WebElement> price;
	
	
	
	
	public void closeFloat() throws InterruptedException, IOException
	{
		try {
			closeFloat.click();
		}catch (Exception e) {}
	}
	
	public void car()
	{
		selectCar.click();
	}
	
	public void prices()
	{
		double lowest = Double.MAX_VALUE;
        //String lowesttext = "";
        for(WebElement p : price) {
        	String text = p.getText().replaceAll("[^0-9]", "");
        	if(!text.isEmpty()) {
        		double val = Double.parseDouble(text);
        		if(val < lowest) {
        			lowest = val;
        			//lowesttext = "₹" + val;
        		}
        	}
        }
        System.out.println("Lowest SUV Cab Price from Delhi to Manali: ₹" + lowest);
        
        
        
        
	}
	

	
	
}
