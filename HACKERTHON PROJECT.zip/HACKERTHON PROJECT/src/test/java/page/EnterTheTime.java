package page;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class EnterTheTime {
	WebDriver driver;
	WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(5));
	//constructor
	public EnterTheTime(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="//li[@data-cy='HrSlots_81'][7]")
	WebElement s1;
	
	@FindBy(xpath="//li[@data-cy='MinSlots_83'][7]")
	WebElement s2;
	
	@FindBy(className="applyBtn")
	WebElement s3;
	
	@FindBy(xpath="//a[@data-cy='OutstationOneWayWidget_64']")
	WebElement s4;
	
	public void s1()
	{
		s1.click();
	}
	
	public void s2()
	{
		s2.click();
	}
	
	public void s3()
	{
		wait1.until(ExpectedConditions.elementToBeClickable(s3)).click();
		
	}
	
	public void s4()
	{
		s4.click();
		
	}
}
