package page;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class EnterToLocation {
	WebDriver driver;
	WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(5));
	//constructor
	public EnterToLocation(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		
	}
  


@FindBy(id="toCity")
	WebElement tocity;
	
	@FindBy(xpath="//input[@placeholder='To']")
	WebElement toInput;
	
	@FindBy(xpath="//span[text()='Manali, Himachal Pradesh, India']")
	WebElement toOptions;
	
	public void tocity()
	{
		tocity.click();
	}
	
	public void toInput()
	{
		wait1.until(ExpectedConditions.elementToBeClickable(toInput)).sendKeys("Manali");
		
	}
	
	public void toOptions()
	{
		wait1.until(ExpectedConditions.elementToBeClickable(toOptions)).click();
	}
}
