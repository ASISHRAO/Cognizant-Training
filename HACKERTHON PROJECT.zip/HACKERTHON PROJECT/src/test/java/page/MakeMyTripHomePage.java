package page;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MakeMyTripHomePage 
{
	//Constructor
	public MakeMyTripHomePage(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		
	}
	//loctor
	@FindBy(xpath="//span[@data-cy='closeModal']")
	WebElement closeLoginPopup;
	
	@FindBy(xpath="//span[@data-cy='travel-card-close']")
	WebElement closeFloat;
	
	@FindBy(xpath="//span[text()='Cabs']")
	WebElement clickOncabs;
	
	@FindBy(xpath="//li[text()='Outstation One-Way']")
	WebElement clickOnstation;
	
	
	//action

	public void closePopup() throws InterruptedException, IOException
	{
		try {
			closeLoginPopup.click();
		}catch(Exception e) {}
		
	}
	
	public void Closecard() throws InterruptedException, IOException
	{
		try {
			closeFloat.click();
		}catch(Exception e) {}
		
	}
	

	public void clickOncabs()
	{
			clickOncabs.click();
	}
	
	public void OutStation()
	{
		
			clickOnstation.click();
		
		
	}
	
	
  }

