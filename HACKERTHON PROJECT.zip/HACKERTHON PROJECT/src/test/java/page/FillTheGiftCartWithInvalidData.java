package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FillTheGiftCartWithInvalidData 
{
	public FillTheGiftCartWithInvalidData(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(id="gift_card_count")
	WebElement giftcard;
	
	@FindBy(id="name")
	WebElement name;
	
	@FindBy(id="email")
	WebElement email;
	
	@FindBy(id="phone_number")
	WebElement phone;
	
	@FindBy(id="location")
	WebElement loc;
	
	@FindBy(xpath="//i[@data-cy='MobileCodeDropDown_60']")
	WebElement prop;
	
	@FindBy(xpath="//div[@data-cy=\'Festive Gifting\']")
	WebElement gif;
	
	@FindBy(id="submitButton")
	WebElement submit;
	
	
	public void giftcard()
	{
		giftcard.sendKeys("1000");
	}
	public void name()
	{
		name.sendKeys("Abhi");
	}
	public void email()
	{
		email.sendKeys("Abhi123com");
	}
	public void phone()
	{
		phone.sendKeys("122434434");
	}
	public void loc()
	{
		loc.sendKeys("Banglore");
	}
	public void prop()
	{
		prop.click();
	}
	public void gif()
	{
		gif.click();
	}
	public void submit()
	{
		submit.click();
		System.out.println("Group Gifting - Invalid Email");
	}
	
}
