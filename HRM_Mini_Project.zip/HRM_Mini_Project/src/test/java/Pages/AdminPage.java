package Pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class AdminPage 
{
	//constructer
	public AdminPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	//Locator
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a")
	WebElement admin;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[2]/span")
	WebElement jobTab;
	
	@FindBy(xpath = "//a[@class='oxd-topbar-body-nav-tab-link']")
	WebElement jobTitle;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[2]/div[2]/div/div/div[3]/div/div[2]/div/div/div[2]/div")
	List<WebElement> JobList;
	
	
	//Action
	@Test(priority = 1)
	public void ClickOnAdmin()
	{
		admin.click();
		//System.out.println("Clicked on admin");
	}
	

	@Test(priority = 2)
	public void clickOnJobTab()
	{
		//System.out.println("Clicked on JobTab");
		jobTab.click();
	}
	
	@Test(priority = 3)
	public void clickOnJobTitle()
	{
		//System.out.println("Clicked on Jobtitle");
		jobTitle.click();
	}
	
	@Test(priority = 4)
	public void PrintAllTheJobTiles()
	{
		int size = JobList.size();
		System.out.println("The Total Jobs are - "+size);
		System.out.println("The List Of Jobs are :"); 
		for(int i =0;i<JobList.size();i++)
		{
			System.out.println(JobList.get(i).getText());
			
		}
	}
	
	
	
}
