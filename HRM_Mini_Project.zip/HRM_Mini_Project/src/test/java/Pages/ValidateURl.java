package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class ValidateURl 
{
	//constuctor
	String CurrentURL;
	SoftAssert sa = new SoftAssert();
	public ValidateURl(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
		CurrentURL = driver.getCurrentUrl();
	}
	//locator
	@FindBy(xpath = "//span[text()='Dashboard']")
	WebElement Dashboard;
	
	
	//Action
	@SuppressWarnings("unused")
	@Test(priority = 1)
	public void dashboradpresent()
	{

		boolean State = Dashboard.isDisplayed();
		if(State = true)
		{
			System.out.println("The DashBoard is present");
			sa.assertTrue(true);
		}
		else
		{
			System.out.println("The DashBoard is not Present");
			sa.fail();
		}
	}
	@Test(priority = 2)
	public void Validate_Url(String acturl)
	{
		if(CurrentURL.equalsIgnoreCase(acturl))
		{
			System.out.println(CurrentURL+"    "+acturl);
			System.out.println("Url same");
			sa.assertEquals(CurrentURL, acturl);
		}
		else
		{
			System.out.println(CurrentURL+"    "+acturl);
			System.out.println("Not same");
			sa.assertEquals(CurrentURL, acturl);
			sa.fail();
		}
	}
	
	
	


}
