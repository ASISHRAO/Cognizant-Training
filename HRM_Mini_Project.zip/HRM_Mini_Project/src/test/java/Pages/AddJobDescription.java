package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddJobDescription 
{
	public AddJobDescription(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='app']/div[1]/div[2]/div[2]/div/div/div[1]/div/button")
	WebElement addButton;
	
	@FindBy(xpath = "//div[@class='oxd-form-row']//input[@class='oxd-input oxd-input--active']")
	WebElement addJobTitle;
	
	@FindBy(xpath = "//textarea[@placeholder='Type description here']")
	WebElement addJobDesc;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[3]/div/div[2]/input")
	WebElement clickBrowse;
	
	@FindBy(xpath="//textarea[@placeholder='Add note']")
	WebElement addNote;
	
	@FindBy(xpath = "//button[@class='oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space']")
	WebElement save;
	
	//Action
	public void clickOnAdd()
	{
		addButton.click();
	}
	
	public void addJobTitle(String jd)
	{
		addJobTitle.sendKeys(jd);
	}
	
	public void addJobDesc(String desc)
	{
		addJobDesc.sendKeys(desc);
	}
	
	public void addBrowserDetials1(String prop)
	{
		// TODO Auto-generated method stub

		clickBrowse.sendKeys(prop);
	}

	public void addNote(String addNot)
	{
		addNote.sendKeys(addNot);
	}
	
	public void clickOnSave()
	{
		save.click();
	}


	
	
}
