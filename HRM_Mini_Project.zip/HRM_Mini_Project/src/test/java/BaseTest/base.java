package BaseTest;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

public class base 
{
	public WebDriver driver;
  @BeforeClass
  public void setUp() throws InterruptedException 
  {
	  driver = new ChromeDriver();
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	  driver.manage().window().maximize();
	  System.out.println("browser opended");
	  Thread.sleep(3000);
	  
  }
  
  @Parameters("browser")
  public void setUp(@Optional("chrome") String browser)
  {
	  switch(browser)
	  {
		  case "chrome":
			  driver = new ChromeDriver();
			  break;
		  case "firefox":
			  driver = new FirefoxDriver();
			  break;
		  case "edge":
			  driver = new EdgeDriver();
			  break;
		  default :
			  return;
	  }
  }
  
  @AfterClass
  public void tearDown() {
	  driver.close();
  }
}
