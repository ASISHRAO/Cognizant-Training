package Test;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseTest.base;
import Pages.AddJobDescription;
import Pages.AdminPage;
import Pages.LoginPage;
import Pages.LogoutProcess;
import Pages.ValidateURl;

public class HRM_Test extends base 
{
	LoginPage login;
	ValidateURl url;
	AdminPage adp;
	AddJobDescription ajd;
	LogoutProcess Logout;
	
	@BeforeClass
	public void RunHRM()
	{
		
		login = new LoginPage(driver);
		url = new ValidateURl(driver);
		adp = new AdminPage(driver);
		ajd = new AddJobDescription(driver);
		Logout = new LogoutProcess(driver);
	}
	
	@BeforeClass
	public void setup()
	{
		login.loginHRM("Admin", "admin123");
	}	
	@Test(priority = 1)
	public void Validation1()
	{
		
		url.Validate_Url("https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
		
		url.dashboradpresent();
	}
	@Test(priority = 2)
	public void Validation2()
	{
		adp.ClickOnAdmin();
		
		adp.clickOnJobTab();
		
		adp.clickOnJobTitle();
		
		adp.PrintAllTheJobTiles();
	}
	@Test(priority = 3)
	public void Validation3()
	{
		ajd.clickOnAdd();
		
		ajd.addJobTitle("AUTOMATION Tester");
		
		ajd.addJobDesc("Selenium with Java Testers");
		
		
		ajd.addBrowserDetials1("C:\\Users\\2408349\\Downloads\\Session1.pdf");
		
		ajd.addNote("required java.");
		
		
		ajd.clickOnSave();
		
	}	
	@AfterClass
	public void Logout()
	{
		Logout.clickOnProfile();
		
		Logout.clickOnLogout();
		
	}
}
